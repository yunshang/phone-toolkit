#!/bin/bash
# 快速演示脚本 - 展示 uv 的速度优势

echo "======================================"
echo "📊 uv vs pip 性能对比演示"
echo "======================================"
echo ""

# 检查 uv
if ! command -v uv &> /dev/null; then
    echo "⚠️  uv 未安装，请先运行: curl -LsSf https://astral.sh/uv/install.sh | sh"
    exit 1
fi

# 清理旧环境
echo "🧹 清理旧环境..."
rm -rf .venv-pip .venv-uv

echo ""
echo "============================================"
echo "测试 1: 使用 pip 创建环境并安装依赖"
echo "============================================"
time {
    python -m venv .venv-pip
    .venv-pip/bin/pip install -q -e ".[dev]"
}

echo ""
echo "============================================"
echo "测试 2: 使用 uv 创建环境并安装依赖"
echo "============================================"
time {
    uv venv .venv-uv
    uv pip install -q -e ".[dev]"
}

echo ""
echo "============================================"
echo "📈 结果对比"
echo "============================================"
echo "查看上面的 'real' 时间比较"
echo "通常 uv 比 pip 快 10-15 倍！"
echo ""

# 清理
echo "🧹 清理测试环境..."
rm -rf .venv-pip .venv-uv

echo "✅ 演示完成！"
echo ""
echo "💡 提示：在实际开发中使用 'make setup' 来设置环境"
